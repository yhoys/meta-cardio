import patientsBundle from "../data/patients.json";

function PatientSelector({ onPatientSelect, disabled = false }) {
  const patients = (patientsBundle.entry || [])
    .map((e) => e.resource)
    .filter((p) => p && p.active);

  const handleChange = (e) => {
    if (disabled) return;
    const id = e.target.value;
    const selected = patients.find((p) => p.id === id) || null;
    onPatientSelect(selected);
  };

  if (!patients.length) {
    return (
      <div className="section-card">
        <h2>Seleccionar paciente</h2>
        <p style={{ color: "#64748b" }}>
          No se encontraron pacientes activos en el Bundle.
        </p>
      </div>
    );
  }

  return (
    <div className="section-card">
      <h2>Seleccionar paciente</h2>
      <small>
        Elija un paciente activo del Bundle para calcular el riesgo
        cardiovascular y metabólico.
      </small>

      <div className="form-field" style={{ maxWidth: "100%" }}>
        <label htmlFor="patient-select">Paciente</label>
        <select
          id="patient-select"
          onChange={handleChange}
          defaultValue=""
          disabled={disabled}
        >
          <option value="" disabled>
            -- Seleccione un paciente --
          </option>

          {patients.map((patient) => {
            const name = patient.name?.[0];
            const given = name?.given?.join(" ") || "";
            const family = name?.family || "";
            const label =
              `${given} ${family}`.trim() || `Paciente ${patient.id}`;

            return (
              <option key={patient.id} value={patient.id}>
                {label}
              </option>
            );
          })}
        </select>
      </div>
    </div>
  );
}

export default PatientSelector;
